Go2 PCD + CSV 巡检准备包

本 ZIP 不复制大型源 PCD；部署时必须使用 SHA-256 与 preparation.json 一致的原始 PCD。

文件：
- source/source.csv：上传时原始 CSV 的精确字节，用来复核 source_csv_sha256
- xbf9_horizontal_clean.aligned.csv：给现有 waypoint_follower_go2_2 执行的五列 CSV
- xbf9_horizontal_clean.alignment.json：原始 CSV 到 PCD map 坐标的唯一 SE(2) 变换
- xbf-2-2.3526e4f11658.annotations.json：固定结构/排除区对象 ROI
- xbf9_horizontal_clean.checkpoints.json：停车重定位点；空数组表示只做起点校准
- preparation.json：源哈希、裁剪范围、地标和 checkpoint 的总绑定

部署前处理：
1. 把本 ZIP 和上传时同一份原始 PCD 交给 localization_upgrade/scripts/import_platform_preparation.sh。
2. 导入器会交叉核对全部哈希，并生成不可变地图、路线、checkpoint 与 deployment.env。
3. source deployment.env 后先做静止校准，等待 coordinator 明确进入 RUNNING。
4. 再做 5–10 m 低速短测；平台确认不等于真狗闭环已经通过。
